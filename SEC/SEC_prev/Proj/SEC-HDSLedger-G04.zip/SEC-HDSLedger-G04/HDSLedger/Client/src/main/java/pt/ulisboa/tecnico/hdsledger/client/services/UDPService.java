package pt.ulisboa.tecnico.hdsledger.client.services;

public interface UDPService {
    void listen();
}
