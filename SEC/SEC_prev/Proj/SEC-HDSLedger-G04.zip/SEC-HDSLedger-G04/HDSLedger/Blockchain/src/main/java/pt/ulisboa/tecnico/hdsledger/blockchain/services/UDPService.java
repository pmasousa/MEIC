package pt.ulisboa.tecnico.hdsledger.blockchain.services;

public interface UDPService {
    void listen();
}
