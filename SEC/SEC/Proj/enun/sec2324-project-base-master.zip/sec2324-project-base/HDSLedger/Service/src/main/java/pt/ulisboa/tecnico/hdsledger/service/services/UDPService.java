package pt.ulisboa.tecnico.hdsledger.service.services;

public interface UDPService {
    void listen();
}
