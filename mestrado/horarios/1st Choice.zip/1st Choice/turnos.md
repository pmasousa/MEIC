## LN
- Dias na Alameda - Terças e Quintas

- Labs - L05 (**preferencial**), L07, L08 (L06 em último caso, enorme overlap com teórica de PADI)

- Teórica - T03 (**preferencial**), T02

## PADI (Desenvolvimento de Aplicações Distribuídas)
- Dias na Alameda - Segundas, Quartas, Sextas

- Labs - L04, L03, L07

- Teórica - **T01** só! (T02 é Tagus)

## CCEIC I
- Dias na Alameda - Terças, Quartas, Quintas

- TPs - todos exceto os de sexta (TP07, TP08)